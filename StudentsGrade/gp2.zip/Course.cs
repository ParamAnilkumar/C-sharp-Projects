﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace gp2prac
{
    class Course
    {
        private string name;
        private int maxStudents;
        private Student[] students;

        public Course(string name, int maxStudents)
        {
            this.name = name;
            this.maxStudents = maxStudents;
            this.students = new Student[maxStudents];
        }

        public string Name { get =>name; set => name = value; }
        public int MaxStudents { get => maxStudents;set => maxStudents = value; }

        public Student[] Students { get => students; set => students = value;}

        public void AddStudnetToCourse(Student student)
        {
            for (int i = 0; i < maxStudents ; i++) 
            {
                if (students[i] == null)
                {
                    students[i] = student;
                    break;
                }

            }
        }

        public double GetCourseAveragGrade(Course course)
        {
            double sum = 0;
            int count = 0;

            for(int i = 0; i < count; i++)
            {
                sum += students[i].GetAverageGrade(students[i]);
            }

            return sum / count;
        }

        public override string ToString()
        {
            return $"Course: {name}, Maximum Students: {maxStudents}, Enrolled Students: {Array.IndexOf(students, null)}";
        }


    }
}
